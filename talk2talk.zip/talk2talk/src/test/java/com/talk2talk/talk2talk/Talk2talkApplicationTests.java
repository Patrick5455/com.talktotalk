package com.talk2talk.talk2talk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Talk2talkApplicationTests {

	@Test
	void contextLoads() {
	}

}
