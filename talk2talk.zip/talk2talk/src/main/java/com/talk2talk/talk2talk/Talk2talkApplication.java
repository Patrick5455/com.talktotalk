package com.talk2talk.talk2talk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Talk2talkApplication {

	public static void main(String[] args) {
		SpringApplication.run(Talk2talkApplication.class, args);
	}

}
